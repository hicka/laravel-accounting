<?php

namespace Hickr\Accounting\Modules\Mira\Reports;

class FixedAssetRegisterReport
{

}